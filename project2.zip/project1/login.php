<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style4 {
	font-size: 24px;
	color: #000000;
}
.style5 {font-size: 24px}
-->
</style>
</head>

<body>
 <div align="center" class="style1">enter your name and password to log in </div>
 <table width="2305" border="1">
   <tr>
     <td height="39"><form id="form1" name="form1" method="post" action="">
       <label>
       <div align="center" class="style4">Name
         <input type="text" name="textfield" />
         <br />
       </div>
       <div align="center"><span class="style4">Password
           <input name="textfield2" type="text" value="" />
       </span> <br />
       <br />
       <span class="style5">Log in
       <input type="submit" name="Submit" value="Submit" />
       </span></div>
       </label>
                    </form>
     </td>
   </tr>
 </table>
</body>
</html>
