<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 36px;
	color: #00254A;
	font-weight: bold;
}
.style4 {font-size: 36px}
.style5 {
	color: #00254A;
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
	font-size: 36pt;
}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<table width="2290" border="1">
  <tr>
    <td width="2316"><div align="center">
      <p class="style1"> Welcome to our website </p>
    </div></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="2279" height="262" border="1">
  <tr>
    <td width="451"><div align="right"><img src="Photos/MainLogo.jpg" width="223" height="229" /></div></td>
    <td width="1418"><div align="center" class="style4">
      <p class="style5"> THE FUTURE </p>
      <p class="style5">OF </p>
      <p class="style5">COMPANION ROBOTS IN DAILY LIFE </p>
    </div></td>
    <td width="388"><div align="left"><img src="Photos/photo_2025-11-30_18-47-58.jpg" width="144" height="257" /></div></td>
  </tr>
</table>
<table width="1383" height="596" border="1">
  <tr>
    <td width="773" height="590"><p>Introduction</p>
        <p>Companion robots are becoming one of the most interesting and promising technologies of our time. These robots are designed not only to perform tasks, but also to communicate, interact, and build emotional connections with people. As technological tools become smarter and more human-like, companion robots are slowly turning into supportive partners that can assist individuals in their everyday activities. Today, they are used in homes, hospitals, schools, and even workplaces, providing help, comfort, and companionship to people of different ages.</p>
      <p>In recent years, rapid advancements in artificial intelligence, sensors, and robotics have allowed companion robots to understand human emotions, respond naturally, and even learn from experience. This improvement is creating a new type of relationship between humans and machines&mdash;one that focuses on trust, safety, and emotional support rather than just mechanical assistance.</p>
    <p>The growing presence of companion robots shows that they will play a major role in shaping the future of daily life. They are expected to support the elderly, help individuals with disabilities, assist children in learning, and even reduce feelings of loneliness. As the technology continues to evolve, these robots will become more capable, more intelligent, and more integrated into our daily routines.</p></td>
    <td width="594"><img src="../../../Users/Jasra/OneDrive/Documentos/Unnamed Site 1/1.jpg" width="368" height="335" /></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
